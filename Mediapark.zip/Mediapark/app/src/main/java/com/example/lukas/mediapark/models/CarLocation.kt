package com.example.lukas.mediapark.models

data class CarLocation(val id: Long?, val latitude: Float?,
                       val longitude: Float?, val address: String?)