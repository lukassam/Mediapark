package com.example.lukas.mediapark.models

data class CarModel(val id: Long?, val title: String?,
                    val photoUrl: String?)